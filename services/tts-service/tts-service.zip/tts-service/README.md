
# TTS Service (Text-to-Speech)

خدمة **تحويل النص إلى كلام** مبنية بـ **FastAPI** وتتكامل مع **AWS S3** و **Kafka** طبقاً لمتطلبات المشروع.

## المزايا
- `POST /api/tts/synthesize` تحويل نص إلى ملف صوت (MP3/WAV/OGG) ورفعه على S3.
- `GET /api/tts/audio/{id}` إرجاع رابط مؤقت (Presigned URL) لتنزيل الصوت.
- `DELETE /api/tts/audio/{id}` حذف ملف الصوت من S3.
- تكامل اختياري مع Kafka: يستهلك `audio.generation.requested` وينشر `audio.generation.completed`.

---
## المتطلبات قبل التشغيل
1. **Python 3.11** + **pip**.
2. **Visual Studio Code** مع إضافة Python.
3. حساب AWS وإعداد صلاحيات للوصول إلى S3.
4. إنشاء Bucket باسم مثل: `tts-service-storage-dev` في المنطقة المناسبة.

### إعداد بيانات الدخول إلى AWS
- أسهل طريقة: تثبيت AWS CLI ثم تنفيذ:
  ```bash
  aws configure
  ```
  وأدخل: `AWS Access Key ID`, `AWS Secret Access Key`, `Region` (مثال: `eu-central-1`).
- أو استخدم متغيرات البيئة مباشرة:
  ```bash
  export AWS_ACCESS_KEY_ID=YOUR_KEY
  export AWS_SECRET_ACCESS_KEY=YOUR_SECRET
  export AWS_DEFAULT_REGION=eu-central-1
  ```

### متغيرات البيئة المطلوبة
انسخ الملف `.env.example` إلى `.env` وعدل القيم:
```
ENV=dev
S3_BUCKET=tts-service-storage-dev
AWS_REGION=eu-central-1
# اختياري لاستخدام KMS بدلاً من SSE-S3
S3_KMS_KEY_ID=
# Kafka اختياري
ENABLE_KAFKA=false
KAFKA_BOOTSTRAP_SERVERS=localhost:9092
KAFKA_TOPIC_REQUEST=audio.generation.requested
KAFKA_TOPIC_COMPLETED=audio.generation.completed
```

---
## التشغيل على Visual Studio Code (فيجوال)
1. افتح VS Code واختر **File → Open Folder** ثم اختر مجلد `tts-service`.
2. افتح الطرفية المدمجة (**Terminal → New Terminal**).
3. أنشئ بيئة افتراضية وثبّت الاعتمادات:
   ```bash
   python -m venv .venv
   source .venv/bin/activate  # على ويندوز: .venv\Scriptsctivate
   pip install -r requirements.txt
   ```
4. شغّل الخدمة:
   ```bash
   uvicorn app.main:app --reload --port 8000
   ```
5. جرّب الطلبات:
   - **تحويل نص لصوت**:
     ```bash
     curl -X POST http://localhost:8000/api/tts/synthesize        -H 'Content-Type: application/json'        -d '{"text":"مرحبا نجمة، هذا اختبار الصوت","language":"ar","format":"mp3"}'
     ```
   - **جلب رابط الصوت**:
     ```bash
     curl http://localhost:8000/api/tts/audio/REPLACE_ID
     ```
   - **حذف الصوت**:
     ```bash
     curl -X DELETE http://localhost:8000/api/tts/audio/REPLACE_ID
     ```

### ربط الخدمة بـ AWS S3
- تأكد أن المستخدم/الدور لديه الصلاحيات التالية على الـ bucket:
  - `s3:PutObject`, `s3:GetObject`, `s3:DeleteObject`, `s3:ListBucket`, ويفضل `s3:PutObjectTagging`.
- استخدم السياسة المرفقة في `scripts/sample_iam_policy.json` وعدل اسم الـ bucket.
- فعّل **Versioning** و**Default Encryption** (SSE-S3 أو KMS) من إعدادات S3.

### ملاحظات الأمان
- لا تحفظ المفاتيح داخل الكود. استخدم AWS CLI أو متغيرات البيئة أو IAM Role عند التشغيل داخل AWS.
- يمكن تفعيل KMS عبر ضبط `S3_KMS_KEY_ID` في `.env`.

---
## Docker
لبناء وتشغيل الحاوية محلياً:
```bash
docker build -t tts-service:dev .
# التشغيل وتمرير المتغيرات
docker run --rm -p 8000:8000   -e ENV=dev -e S3_BUCKET=tts-service-storage-dev -e AWS_REGION=eu-central-1   -e AWS_ACCESS_KEY_ID=YOUR_KEY -e AWS_SECRET_ACCESS_KEY=YOUR_SECRET   tts-service:dev
```

---
## هيكل المشروع
```
app/
  main.py            # FastAPI endpoints
  tts_engine.py      # gTTS / Polly wrapper
  storage.py         # S3 operations (upload, presign, delete)
  kafka_client.py    # Kafka producer/consumer (optional)
  config.py          # Env/config loader
scripts/
  sample_iam_policy.json
  create_bucket_policy.json
requirements.txt
Dockerfile
.env.example
README.md
```

## الاختبارات السريعة
- ملف `api.http` (إن رغبت) يمكن فتحه في VS Code لإرسال الطلبات مباشرة.

بالتوفيق يا نجمة! لو حابة أضيف دعم AWS Polly بدل gTTS، فعّلي `USE_POLLY=true` وأضبط صلاحيات IAM لـ `polly:SynthesizeSpeech`.
