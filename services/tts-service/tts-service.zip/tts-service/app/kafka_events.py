
"""Kafka integration: consumer for audio.generation.requested and producer for audio.generation.completed.
This module is optional; enable via KAFKA_ENABLED=true.
"""
from __future__ import annotations
import asyncio, json
from typing import Any

from .config import settings

try:
    from aiokafka import AIOKafkaConsumer, AIOKafkaProducer
except Exception:  # pragma: no cover
    AIOKafkaConsumer = None
    AIOKafkaProducer = None

producer: AIOKafkaProducer | None = None

async def start_producer():
    global producer
    if not settings.kafka_enabled or AIOKafkaProducer is None:
        return
    producer = AIOKafkaProducer(bootstrap_servers=settings.kafka_bootstrap_servers)
    await producer.start()

async def stop_producer():
    global producer
    if producer:
        await producer.stop()
        producer = None

async def publish_completed(payload: dict):
    if not settings.kafka_enabled or producer is None:
        return
    await producer.send_and_wait(settings.kafka_topic_completed, json.dumps(payload).encode('utf-8'))

async def start_consumer(app_callback):
    if not settings.kafka_enabled or AIOKafkaConsumer is None:
        return
    consumer = AIOKafkaConsumer(
        settings.kafka_topic_request,
        bootstrap_servers=settings.kafka_bootstrap_servers,
        group_id='tts-service',
        enable_auto_commit=True,
        auto_offset_reset='earliest'
    )
    await consumer.start()
    try:
        async for msg in consumer:
            try:
                data = json.loads(msg.value.decode('utf-8'))
                # Expecting {"text": "...", "voice": "...", "language": "...", "format": "mp3"}
                await app_callback(data)
            except Exception as e:
                print('Kafka consumer error:', e)
    finally:
        await consumer.stop()
