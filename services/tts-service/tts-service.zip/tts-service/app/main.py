
from fastapi import FastAPI, HTTPException
from fastapi import Body
from pydantic import BaseModel, Field
from uuid import uuid4
from .storage import Storage
from .tts_engine import TTS
from .kafka_client import KafkaClient
from .config import (
    ENABLE_KAFKA, KAFKA_BOOTSTRAP_SERVERS,
    KAFKA_TOPIC_REQUEST, KAFKA_TOPIC_COMPLETED
)

app = FastAPI(title="TTS Service", version="1.0.0")

storage = Storage()
tts = TTS()

kafka = None
if ENABLE_KAFKA:
    kafka = KafkaClient(KAFKA_BOOTSTRAP_SERVERS)

class SynthesizeRequest(BaseModel):
    text: str = Field(..., min_length=1, description="Text to synthesize")
    language: str | None = Field(default='ar', description="Language code (e.g., 'ar', 'en')")
    format: str | None = Field(default='mp3', description="Audio format: mp3|wav|ogg")

@app.get('/health')
def health():
    return {"status":"ok"}

@app.post('/api/tts/synthesize')
def synthesize(req: SynthesizeRequest = Body(...)):
    # Generate audio bytes and default filename
    audio_bytes, content_type, ext = tts.synthesize(req.text, language=req.language, fmt=req.format)
    audio_id = str(uuid4())
    key = f"audio/{audio_id}.{ext}"

    # Upload to S3
    storage.upload_bytes(key, audio_bytes, content_type)

    # Publish kafka event when enabled
    if kafka:
        kafka.produce(KAFKA_TOPIC_COMPLETED, {
            'id': audio_id,
            's3_key': key,
            'content_type': content_type
        })

    return {"id": audio_id, "s3_key": key}

@app.get('/api/tts/audio/{audio_id}')
def get_audio(audio_id: str):
    # Generate presigned URL
    # Try multiple common extensions
    for ext in ('mp3','wav','ogg'):
        key = f"audio/{audio_id}.{ext}"
        if storage.exists(key):
            url = storage.presign(key)
            return {"id": audio_id, "url": url}
    raise HTTPException(status_code=404, detail="Audio not found")

@app.delete('/api/tts/audio/{audio_id}')
def delete_audio(audio_id: str):
    deleted=False
    for ext in ('mp3','wav','ogg'):
        key = f"audio/{audio_id}.{ext}"
        if storage.exists(key):
            storage.delete(key)
            deleted=True
    if not deleted:
        raise HTTPException(status_code=404, detail="Audio not found")
    return {"id": audio_id, "deleted": True}

# Optional: Kafka consumer endpoint starter (run separately)
@app.on_event("startup")
def on_startup():
    # Could start background consumer here if desired
    pass
