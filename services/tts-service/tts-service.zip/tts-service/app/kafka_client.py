
# Simple Kafka client
import json
from kafka import KafkaProducer, KafkaConsumer
from .config import (
    ENABLE_KAFKA, KAFKA_BOOTSTRAP_SERVERS,
    KAFKA_TOPIC_REQUEST, KAFKA_TOPIC_COMPLETED
)
from .storage import Storage
from .tts_engine import TTS

class KafkaClient:
    def __init__(self, servers: str):
        self.producer = KafkaProducer(bootstrap_servers=servers, value_serializer=lambda v: json.dumps(v).encode('utf-8'))

    def produce(self, topic: str, payload: dict):
        self.producer.send(topic, payload)
        self.producer.flush()

# Optional consumer example (run as a separate process)

def run_consumer():
    if not ENABLE_KAFKA:
        print('Kafka disabled')
        return
    consumer = KafkaConsumer(
        KAFKA_TOPIC_REQUEST,
        bootstrap_servers=KAFKA_BOOTSTRAP_SERVERS,
        value_deserializer=lambda m: json.loads(m.decode('utf-8')),
        group_id='tts-service-group',
        auto_offset_reset='latest'
    )
    storage = Storage()
    tts = TTS()
    for msg in consumer:
        payload = msg.value
        text = payload.get('text','')
        language = payload.get('language','ar')
        fmt = payload.get('format','mp3')
        audio_bytes, content_type, ext = tts.synthesize(text, language, fmt)
        import uuid
        audio_id = str(uuid.uuid4())
        key = f"audio/{audio_id}.{ext}"
        storage.upload_bytes(key, audio_bytes, content_type)
        producer = KafkaProducer(bootstrap_servers=KAFKA_BOOTSTRAP_SERVERS, value_serializer=lambda v: json.dumps(v).encode('utf-8'))
        producer.send(KAFKA_TOPIC_COMPLETED, {'id': audio_id, 's3_key': key, 'content_type': content_type})
        producer.flush()
