
# S3 storage helper
import boto3
from botocore.exceptions import ClientError
from .config import S3_BUCKET, AWS_REGION, S3_KMS_KEY_ID

class Storage:
    def __init__(self):
        self.s3 = boto3.client('s3', region_name=AWS_REGION)
        self.bucket = S3_BUCKET

    def upload_bytes(self, key: str, data: bytes, content_type: str):
        extra = {'ContentType': content_type}
        if S3_KMS_KEY_ID:
            extra['ServerSideEncryption'] = 'aws:kms'
            extra['SSEKMSKeyId'] = S3_KMS_KEY_ID
        else:
            extra['ServerSideEncryption'] = 'AES256'
        self.s3.put_object(Bucket=self.bucket, Key=key, Body=data, **extra)

    def presign(self, key: str, expires=3600):
        return self.s3.generate_presigned_url('get_object', Params={'Bucket': self.bucket, 'Key': key}, ExpiresIn=expires)

    def delete(self, key: str):
        self.s3.delete_object(Bucket=self.bucket, Key=key)

    def exists(self, key: str) -> bool:
        try:
            self.s3.head_object(Bucket=self.bucket, Key=key)
            return True
        except ClientError:
            return False
