
# TTS engine wrapper
# By default uses gTTS (offline-ish requires network for Google TTS). For AWS environments, switch to Polly.
from io import BytesIO
from gtts import gTTS
import os
from .config import USE_POLLY, VOICE_ID

class TTS:
    def __init__(self):
        self.use_polly = USE_POLLY
        if self.use_polly:
            import boto3
            self.polly = boto3.client('polly')

    def synthesize(self, text: str, language: str='ar', fmt: str='mp3'):
        fmt = fmt.lower()
        if self.use_polly:
            ext = 'mp3' if fmt=='mp3' else 'ogg'
            ct = 'audio/mpeg' if ext=='mp3' else 'audio/ogg'
            response = self.polly.synthesize_speech(
                Text=text,
                OutputFormat=ext.upper(),
                VoiceId=VOICE_ID,
                LanguageCode='ar-SA' if language=='ar' else 'en-US'
            )
            audio_bytes = response['AudioStream'].read()
            return audio_bytes, ct, ext
        else:
            # gTTS supports mp3 only; we'll normalize accordingly
            tts = gTTS(text=text, lang=language or 'ar')
            buf = BytesIO()
            tts.write_to_fp(buf)
            audio_bytes = buf.getvalue()
            return audio_bytes, 'audio/mpeg', 'mp3'
