
"""S3 storage helpers: upload, presign, delete."""
from __future__ import annotations
import boto3
from botocore.config import Config as BotoConfig
from .config import settings
import os

_client = None

def _init_client():
    global _client
    if _client:
        return _client
    session_kwargs = {}
    if settings.aws_profile:
        session_kwargs['profile_name'] = settings.aws_profile
    session = boto3.Session(**session_kwargs) if session_kwargs else boto3.Session(
        aws_access_key_id=settings.aws_access_key_id,
        aws_secret_access_key=settings.aws_secret_access_key,
        region_name=settings.aws_region
    )
    _client = session.client('s3', config=BotoConfig(signature_version='s3v4'), region_name=settings.aws_region)
    return _client

def upload_file(local_path: str, object_key: str) -> str:
    """Upload file to S3 and return s3:// URL."""
    client = _init_client()
    client.upload_file(local_path, settings.s3_bucket, object_key)
    return f"s3://{settings.s3_bucket}/{object_key}"

def presign_url(object_key: str, expires_in: int = 3600) -> str:
    client = _init_client()
    return client.generate_presigned_url(
        'get_object',
        Params={'Bucket': settings.s3_bucket, 'Key': object_key},
        ExpiresIn=expires_in
    )

def delete_object(object_key: str) -> None:
    client = _init_client()
    client.delete_object(Bucket=settings.s3_bucket, Key=object_key)
