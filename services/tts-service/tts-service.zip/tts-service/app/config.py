
import os
from dotenv import load_dotenv

load_dotenv()

ENV=os.getenv('ENV','dev')
AWS_REGION=os.getenv('AWS_REGION','eu-central-1')
S3_BUCKET=os.getenv('S3_BUCKET','tts-service-storage-dev')
S3_KMS_KEY_ID=os.getenv('S3_KMS_KEY_ID')

ENABLE_KAFKA=os.getenv('ENABLE_KAFKA','false').lower()=='true'
KAFKA_BOOTSTRAP_SERVERS=os.getenv('KAFKA_BOOTSTRAP_SERVERS','localhost:9092')
KAFKA_TOPIC_REQUEST=os.getenv('KAFKA_TOPIC_REQUEST','audio.generation.requested')
KAFKA_TOPIC_COMPLETED=os.getenv('KAFKA_TOPIC_COMPLETED','audio.generation.completed')

USE_POLLY=os.getenv('USE_POLLY','false').lower()=='true'
VOICE_ID=os.getenv('VOICE_ID','Joanna')
