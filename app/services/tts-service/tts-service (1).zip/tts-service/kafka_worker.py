import json
import threading
import traceback
from typing import Callable, Optional

from kafka import KafkaConsumer, KafkaProducer

from config import (
    KAFKA_BOOTSTRAP_SERVERS,
    KAFKA_GROUP_ID,
    KAFKA_TOPIC_REQUESTED,
    KAFKA_TOPIC_COMPLETED,
)

class KafkaWorker:
    """
    Simple Kafka worker that consumes 'audio.generation.requested' and
    produces 'audio.generation.completed'.
    """

    def __init__(self, synthesize_fn: Callable[[str, str, str], str]):
        """
        synthesize_fn: function(text, lang, tld) -> id
        """
        self.synthesize_fn = synthesize_fn
        self._consumer: Optional[KafkaConsumer] = None
        self._producer: Optional[KafkaProducer] = None
        self._thread: Optional[threading.Thread] = None
        self._stop_flag = threading.Event()

    def start(self):
        self._producer = KafkaProducer(
            bootstrap_servers=KAFKA_BOOTSTRAP_SERVERS,
            value_serializer=lambda v: json.dumps(v).encode("utf-8"),
            retries=3,
        )
        self._consumer = KafkaConsumer(
            KAFKA_TOPIC_REQUESTED,
            bootstrap_servers=KAFKA_BOOTSTRAP_SERVERS,
            group_id=KAFKA_GROUP_ID,
            value_deserializer=lambda v: json.loads(v.decode("utf-8")),
            enable_auto_commit=True,
            auto_offset_reset="earliest",
        )
        self._thread = threading.Thread(target=self._run, daemon=True)
        self._thread.start()

    def _run(self):
        for msg in self._consumer:
            if self._stop_flag.is_set():
                break
            try:
                payload = msg.value or {}
                text = payload.get("text", "")
                lang = payload.get("lang", "en")
                tld = payload.get("tld", "com")
                correlation_id = payload.get("correlation_id")

                # Synthesize and get audio id
                audio_id = self.synthesize_fn(text, lang, tld)

                completed_event = {
                    "id": audio_id,
                    "format": "mp3",
                    "correlation_id": correlation_id,
                    "status": "completed",
                }
                self._producer.send(KAFKA_TOPIC_COMPLETED, completed_event)
                self._producer.flush()
            except Exception:
                traceback.print_exc()

    def stop(self):
        self._stop_flag.set()
        try:
            if self._consumer:
                self._consumer.close()
            if self._producer:
                self._producer.close()
        except Exception:
            pass
