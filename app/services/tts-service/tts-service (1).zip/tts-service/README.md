# Local TTS Service (Phase 2 - Local Storage)

## تشغيل سريع

### 1) تفعيل بيئة بايثون
```bash
python -m venv .venv
# Windows PowerShell
.\.venv\Scripts\Activate.ps1
# macOS/Linux
# source .venv/bin/activate
```

### 2) تثبيت الاعتمادات
```bash
pip install -r requirements.txt
```

### 3) نسخ ملف المتغيرات
```bash
copy .env.example .env   # Windows
# أو
cp .env.example .env     # macOS/Linux
```

### 4) تشغيل السيرفر
```bash
uvicorn app:app --reload --host 127.0.0.1 --port 8000
```

### 5) تجربة من Swagger UI
افتح: http://127.0.0.1:8000/docs

---

## تشغيل كافكا اختياريًا

1) شغّل Docker ثم:
```bash
docker compose up -d
```
2) فعّل كافكا في `.env`:
```
KAFKA_ENABLED=true
```
3) أعد تشغيل السيرفر.

4) أرسل حدث طلب توليد صوت:
```bash
python scripts/publish_request.py
```

ستجد ملفات الصوت في `storage/audio/` ومع كل طلب كافكا سيصدر حدث `audio.generation.completed`.
