import os
from dotenv import load_dotenv

load_dotenv()

HOST = os.getenv("HOST", "127.0.0.1")
PORT = int(os.getenv("PORT", "8000"))

STORAGE_DIR = os.getenv("STORAGE_DIR", "storage/audio")

KAFKA_ENABLED = os.getenv("KAFKA_ENABLED", "false").lower() == "true"
KAFKA_BOOTSTRAP_SERVERS = os.getenv("KAFKA_BOOTSTRAP_SERVERS", "localhost:9092")
KAFKA_GROUP_ID = os.getenv("KAFKA_GROUP_ID", "tts-service-local")
KAFKA_TOPIC_REQUESTED = os.getenv("KAFKA_TOPIC_REQUESTED", "audio.generation.requested")
KAFKA_TOPIC_COMPLETED = os.getenv("KAFKA_TOPIC_COMPLETED", "audio.generation.completed")

TTS_DEFAULT_LANG = os.getenv("TTS_DEFAULT_LANG", "en")
TTS_DEFAULT_TLD = os.getenv("TTS_DEFAULT_TLD", "com")
