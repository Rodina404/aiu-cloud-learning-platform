import os
import uuid
from pathlib import Path

from fastapi import FastAPI, HTTPException
from fastapi.responses import FileResponse
from pydantic import BaseModel, Field
from gtts import gTTS

from config import (
    HOST, PORT, STORAGE_DIR,
    KAFKA_ENABLED,
    TTS_DEFAULT_LANG, TTS_DEFAULT_TLD
)
from kafka_worker import KafkaWorker

app = FastAPI(title="Local TTS Service (Phase 2 - Local Storage)")

# Ensure storage directory exists
Path(STORAGE_DIR).mkdir(parents=True, exist_ok=True)

# ----- Data Models -----
class SynthesizeRequest(BaseModel):
    text: str = Field(..., min_length=1, description="Text to convert to speech")
    lang: str = Field(default=TTS_DEFAULT_LANG, description="Language code (e.g., en, ar, fr)")
    # gTTS doesn't provide voice selection, but TLD can slightly affect accent
    tld: str = Field(default=TTS_DEFAULT_TLD, description="TLD for accent (e.g., com, co.uk)")

class SynthesizeResponse(BaseModel):
    id: str
    filename: str
    url: str
    format: str = "mp3"

# ----- Core TTS function -----

def synthesize_to_file(text: str, lang: str = TTS_DEFAULT_LANG, tld: str = TTS_DEFAULT_TLD) -> str:
    """
    Convert text to speech and save as MP3 locally.
    Returns generated audio ID (UUID).
    """
    audio_id = str(uuid.uuid4())
    filename = f"{audio_id}.mp3"
    file_path = Path(STORAGE_DIR) / filename

    # Use gTTS to synthesize
    tts = gTTS(text=text, lang=lang, tld=tld)
    tts.save(str(file_path))

    return audio_id

# ----- Kafka integration (optional) -----
kafka_worker = None

@app.on_event("startup")
def on_startup():
    global kafka_worker
    if KAFKA_ENABLED:
        try:
            kafka_worker = KafkaWorker(synthesize_fn=synthesize_to_file)
            kafka_worker.start()
        except Exception as e:
            # Do not crash the API if Kafka is not reachable
            print(f"[WARN] Kafka failed to start: {e}")

@app.on_event("shutdown")
def on_shutdown():
    global kafka_worker
    if kafka_worker:
        kafka_worker.stop()

# ----- API Endpoints -----

@app.get("/")
def root():
    return {
        "service": "Local TTS Service",
        "storage": str(Path(STORAGE_DIR).resolve()),
        "kafka_enabled": KAFKA_ENABLED,
        "format_supported": ["mp3"],
        "docs": "/docs"
    }

@app.post("/api/tts/synthesize", response_model=SynthesizeResponse)
def synthesize(req: SynthesizeRequest):
    if not req.text.strip():
        raise HTTPException(status_code=400, detail="Text must not be empty")

    audio_id = synthesize_to_file(req.text, req.lang, req.tld)
    filename = f"{audio_id}.mp3"
    url = f"/api/tts/audio/{audio_id}"
    return SynthesizeResponse(id=audio_id, filename=filename, url=url)

@app.get("/api/tts/audio/{audio_id}")
def get_audio(audio_id: str):
    file_path = Path(STORAGE_DIR) / f"{audio_id}.mp3"
    if not file_path.exists():
        raise HTTPException(status_code=404, detail="Audio not found")
    return FileResponse(path=str(file_path), media_type="audio/mpeg", filename=file_path.name)

@app.delete("/api/tts/audio/{audio_id}")
def delete_audio(audio_id: str):
    file_path = Path(STORAGE_DIR) / f"{audio_id}.mp3"
    if not file_path.exists():
        raise HTTPException(status_code=404, detail="Audio not found")
    try:
        os.remove(file_path)
        return {"id": audio_id, "deleted": True}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))
